# SDLC RSI Documentation Package

Prepared for `C:\WORKSPACE\sdlc-agent`. This archive has **not** been written to
that Windows folder. Direct access to the user's computer was not connected.
The existing repository layout and files have not been inspected.

## Contents

`docs/rsi/README.md` is the entry point. The payload contains seven architecture
and implementation documents, capture and dreaming prompts, a documentation-stage
skill template, three JSON schemas, illustrative records and policy, evaluation
and PR templates, references, and a validation note. These are proposed contracts,
not an implementation of the runtime, GitHub writer, evaluator, or workflow.

## Copy into the existing project

Extract this ZIP into a separate temporary directory, review its contents, then
run the supplied PowerShell script. For a ZIP saved to your Downloads folder:

```powershell
$stage = Join-Path $env:TEMP ("sdlc-rsi-docs-" + [guid]::NewGuid().ToString("N"))
Expand-Archive -LiteralPath "$HOME\Downloads\sdlc-agent-rsi-docs.zip" -DestinationPath $stage
& (Join-Path $stage 'Install-Docs.ps1') -TargetRoot 'C:\WORKSPACE\sdlc-agent'
```

Append `-WhatIf` to the final command to preview destinations without copying.
The target project folder must already exist. Follow your organization's script
execution policy; this package does not bypass or change that policy.

The installer copies only `docs/rsi/` into the project. It checks the SHA-256
manifest, skips identical files, and aborts before copying when an existing file
has differing content. It also rejects symlink/junction paths. It does not
change repository roots, run Git, install dependencies or skills, commit, push,
rename a repository, or change application configuration.

The preflight protects against detected conflicts, but the multi-file copy is
not a transaction against disk failures or concurrent filesystem changes. After
an interrupted copy, rerun it: matching copied files are skipped. Differing files
still require explicit review. The installer is supplied as source and has not
been executed on Windows in the authoring environment.

The manifest checks package consistency, not publisher authenticity. Do not treat
it as a digital signature. No project credentials or real conversation records
are included; all JSON/YAML examples are synthetic.
